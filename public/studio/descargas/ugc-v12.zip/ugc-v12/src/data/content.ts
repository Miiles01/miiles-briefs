// Todo el contenido de la plantilla vive aquí: cambia este archivo para crear otra versión.
const M = "https://wearemiiles.com/ugc-v3/media/";

export const content = {
  name: "Laura",
  tagline: "Creadora de contenido UGC para marcas de belleza, moda y bienestar",
  heroImage: M + "hero.jpg",
  heroSecondary: M + "foto-2.jpg",
  heroNote: "Videos y fotos reales, pensados para que tu producto se vea en uso.",
  cover: M + "portada.jpg",
  coverCaption: "Contenido vertical listo para TikTok, Reels y anuncios.",
  nav: [
    { label: "Marcas", href: "#marcas" },
    { label: "Qué hago", href: "#que-hago" },
    { label: "Contenido", href: "#contenido" },
    { label: "Sobre mí", href: "#sobre-mi" },
    { label: "Testimonios", href: "#testimonios" },
    { label: "Contacto", href: "#contacto" },
  ],
  brandsTitle: "Marcas que confiaron en mí",
  brands: [
    "adidas-13", "chanel-2", "dji-1", "loreal", "la-roche-posay", "samsung-8", "spotify-logo",
    "vichy-laboratoires", "zoah-1", "zara", "vogue", "versace", "pull-bear-2", "bershka-1", "shein",
  ].map((b) => ({ name: b, src: `${M}marcas/${b}.svg` })),
  servicesTitle: "Qué tipo de contenido hago",
  niches: [
    { name: "Belleza", examples: "Skincare, maquillaje, cuidado del cabello" },
    { name: "Moda", examples: "Outfits, hauls, prueba de prendas" },
    { name: "Bienestar", examples: "Fitness, hábitos saludables, autocuidado" },
  ],
  formats: [
    "Unboxing", "Tutoriales", "Reseñas honestas", "Primeras impresiones",
    "Rutinas", "Antes y después", "Testimoniales a cámara", "Fotos de producto", "Fotos lifestyle",
  ],
  workTitle: "Contenido",
  work: [
    { title: "Rutina de cuidado", type: "Video UGC", kind: "video", src: M + "video-1.mp4" },
    { title: "Ropa deportiva", type: "Foto de producto", kind: "image", src: M + "foto-1.jpg" },
    { title: "Primeras impresiones", type: "Video UGC", kind: "video", src: M + "video-2.mp4" },
    { title: "Entrenamiento", type: "Foto lifestyle", kind: "image", src: M + "foto-2.jpg" },
    { title: "Reseña honesta", type: "Video UGC", kind: "video", src: M + "video-3.mp4" },
    { title: "Día al aire libre", type: "Foto lifestyle", kind: "image", src: M + "foto-3.jpg" },
  ] as { title: string; type: string; kind: "video" | "image"; src: string }[],
  aboutTitle: "Sobre mí",
  about: [
    "Soy Laura. Hago videos y fotos que se sienten como la recomendación de una amiga: reales, cercanos y pensados para que tu producto se vea en uso.",
    "Me encargo de la idea, el guion, la grabación y la edición en formato vertical, listo para TikTok, Reels o anuncios.",
  ],
  aboutImages: [M + "sobre-mi.jpg", M + "foto-4.jpg", M + "foto-5.jpg"],
  testimonialsTitle: "Lo que dicen de mí",
  testimonials: [
    ["Laura entendió la visión de nuestra marca desde el primer momento. El contenido superó nuestras expectativas.", "Directora de Marketing", "Tech Innovators"],
    ["Su capacidad para contar historias a través de la fotografía es única. Cada proyecto es un éxito garantizado.", "Fundador", "Artisan Coffee Co."],
    ["El nivel de atención al detalle que Laura le puso a nuestra última campaña fue increíble.", "Directora de Arte", "Fashion Forward"],
    ["Logró capturar la esencia de lo que somos en cada toma. Es una verdadera profesional.", "CEO", "Eco Beauty"],
    ["Transformó por completo la manera en la que nuestra audiencia nos percibe visualmente.", "Brand Manager", "Luxe Events"],
    ["Una creatividad desbordante y una técnica impecable. Sus fotos hablan por sí solas.", "Editor en Jefe", "Revista Estilo"],
  ].map(([quote, role, company], i) => ({ quote, role, company, avatar: `${M}testimonios/persona-${i + 1}.jpg` })),
  contact: {
    title: "Hagamos algo juntas",
    text: "Cuéntame de tu marca y de lo que necesitas. Te respondo en menos de 24 horas.",
    email: "hola@lauracreativa.com",
    // Cambia los enlaces y usuarios por los reales de la creadora.
    socials: [
      { label: "Instagram", handle: "@laura.ugc", href: "https://instagram.com/", icon: "instagram" },
      { label: "TikTok", handle: "@laura.ugc", href: "https://tiktok.com/", icon: "tiktok" },
    ] as { label: string; handle: string; href: string; icon: "instagram" | "tiktok" }[],
  },
  footer: "© 2026 Laura · Plantilla UGC de We Are Miiles",
};

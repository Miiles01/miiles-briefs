import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Instagram, Mail } from "lucide-react";
import { content as c } from "@/data/content";

function TikTokIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6 shrink-0" fill="currentColor" aria-hidden>
      <path d="M16.6 5.82A4.28 4.28 0 0 1 15.54 3h-3.09v12.4a2.59 2.59 0 0 1-2.59 2.5 2.59 2.59 0 0 1-2.59-2.59 2.59 2.59 0 0 1 3.35-2.48V9.68a5.73 5.73 0 0 0-.76-.05A5.68 5.68 0 0 0 4.18 15.3 5.68 5.68 0 0 0 9.86 21a5.68 5.68 0 0 0 5.68-5.68V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3a4.3 4.3 0 0 1-3.24-1.48Z" />
    </svg>
  );
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${c.name} · Creadora de contenido UGC` },
      { name: "description", content: c.tagline },
      { property: "og:title", content: `${c.name} · Creadora de contenido UGC` },
      { property: "og:description", content: c.tagline },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

/** Título que se revela palabra por palabra con máscara (sin cortar descendentes). */
function Reveal({ text, as: Tag = "h2", className = "" }: { text: string; as?: "h1" | "h2" | "h3"; className?: string }) {
  return (
    <Tag className={className} data-reveal aria-label={text}>
      {text.split(" ").map((w, i) => (
        <span key={i} aria-hidden className="inline-block overflow-hidden pt-[0.12em] -mt-[0.12em] pb-[0.18em] -mb-[0.18em] align-bottom">
          <span className="inline-block will-change-transform" data-word>
            {w}
            {"\u00A0"}
          </span>
        </span>
      ))}
    </Tag>
  );
}

function Index() {
  const root = useRef<HTMLDivElement>(null);
  const [menu, setMenu] = useState(false);

  // Animaciones basadas en la plantilla Amber del repo de ideas (GSAP + ScrollTrigger + Lenis).
  useEffect(() => {
    const pre = document.querySelector<HTMLElement>("[data-pre]");
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { pre?.remove(); return; }
    let cleanup = () => {};
    (async () => {
      const [{ gsap }, { ScrollTrigger }, { default: Lenis }] = await Promise.all([
        import("gsap"),
        import("gsap/ScrollTrigger"),
        import("lenis"),
      ]);
      gsap.registerPlugin(ScrollTrigger);
      ScrollTrigger.config({ ignoreMobileResize: true });

      // Smooth scroll
      const lenis = new Lenis({ lerp: 0.09, smoothWheel: true });
      lenis.on("scroll", ScrollTrigger.update);
      const tick = (t: number) => lenis.raf(t * 1000);
      gsap.ticker.add(tick);
      gsap.ticker.lagSmoothing(0);
      lenis.stop();
      (window as unknown as { __lenis?: unknown }).__lenis = lenis;

      // Partir párrafos "scrub" en palabras
      document.querySelectorAll<HTMLElement>("[data-scrub]").forEach((el) => {
        if (el.dataset["split"]) return;
        el.dataset["split"] = "1";
        el.innerHTML = (el.textContent ?? "").split(/\s+/).map((w) => `<span data-sw>${w}</span>`).join(" ");
      });

      const ctx = gsap.context(() => {
        // Estados iniciales (ocultos tras el preloader)
        gsap.set("[data-hero-title] [data-word]", { yPercent: 115 });
        gsap.set(["[data-hero-sub]", "[data-hero-btn]"], { opacity: 0, y: 24 });
        gsap.set("[data-hero-img]", { clipPath: "inset(100% 0 0 0)" });
        gsap.set("[data-hero-img] img", { scale: 1.3 });
        gsap.set("[data-bar]", { yPercent: -120 });

        const intro = gsap.timeline({ paused: true, defaults: { ease: "power4.out" } })
          .to("[data-hero-img]", { clipPath: "inset(0% 0 0 0)", duration: 1.4, stagger: 0.15, ease: "expo.out" }, 0)
          .to("[data-hero-img] img", { scale: 1, duration: 2.2, ease: "expo.out" }, 0)
          .to("[data-hero-title] [data-word]", { yPercent: 0, duration: 1.3, stagger: 0.05 }, 0.15)
          .to("[data-hero-sub]", { opacity: 1, y: 0, duration: 1, stagger: 0.1 }, 0.45)
          .to("[data-hero-btn]", { opacity: 1, y: 0, duration: 1, stagger: 0.08 }, 0.65)
          .to("[data-bar]", { yPercent: 0, duration: 1.1 }, 0.8);

        // Preloader con contador
        let started = false;
        const start = () => {
          if (started) return; started = true;
          gsap.timeline()
            .to(pre, { yPercent: -100, duration: 1.1, ease: "expo.inOut" })
            .add(() => intro.play(), "-=0.55")
            .add(() => { pre?.remove(); lenis.start(); ScrollTrigger.refresh(); });
        };
        const counter = { n: 0 };
        const count = pre?.querySelector("[data-count]");
        gsap.to(counter, {
          n: 100, duration: 1.3, ease: "power2.inOut",
          onUpdate: () => { if (count) count.textContent = String(Math.round(counter.n)); },
          onComplete: start,
        });
        window.setTimeout(start, 5000);

        // Barra: se oculta al bajar y vuelve al subir + progreso
        const bar = document.querySelector<HTMLElement>("[data-bar]");
        ScrollTrigger.create({
          start: 0, end: "max",
          onUpdate: (s) => bar?.classList.toggle("is-hidden", s.direction === 1 && s.scroll() > 240),
        });
        gsap.fromTo("[data-progress]", { scaleX: 0 }, { scaleX: 1, ease: "none", scrollTrigger: { start: 0, end: "max", scrub: 0.3 } });

        // Titulares: palabras suben desde una máscara
        gsap.utils.toArray<HTMLElement>("[data-reveal]:not([data-hero-title])").forEach((el) => {
          const words = el.querySelectorAll("[data-word]");
          gsap.set(words, { yPercent: 115 });
          ScrollTrigger.create({
            trigger: el, start: "top 90%", once: true,
            onEnter: () => gsap.to(words, { yPercent: 0, duration: 1.1, ease: "power4.out", stagger: 0.045 }),
          });
        });

        // Párrafos que se encienden palabra por palabra con el scroll
        gsap.utils.toArray<HTMLElement>("[data-scrub]").forEach((el) => {
          gsap.fromTo(el.querySelectorAll("[data-sw]"), { opacity: 0.14 }, {
            opacity: 1, ease: "none", stagger: 0.12,
            scrollTrigger: { trigger: el, start: "top 85%", end: "bottom 55%", scrub: true },
          });
        });

        // Fotos: máscara + zoom-out
        gsap.utils.toArray<HTMLElement>("[data-img]").forEach((el) => {
          gsap.fromTo(el, { scale: 1.25 }, { scale: 1, duration: 1.6, ease: "expo.out", scrollTrigger: { trigger: el, start: "top 90%", once: true } });
        });

        // Parallax suave
        gsap.utils.toArray<HTMLElement>("[data-parallax]").forEach((el) => {
          gsap.fromTo(el, { yPercent: 0 }, { yPercent: Number(el.dataset["parallax"]), ease: "none", scrollTrigger: { trigger: el, scrub: true } });
        });

        // Bloques: fade + subida escalonada por lotes
        gsap.utils.toArray<HTMLElement>("[data-stagger]").forEach((group) => {
          gsap.set(group.children, { opacity: 0, y: 36 });
          ScrollTrigger.batch(group.children as unknown as Element[], {
            start: "top 92%", once: true,
            onEnter: (els) => gsap.to(els, { opacity: 1, y: 0, duration: 1.1, ease: "power3.out", stagger: 0.1, clearProps: "transform" }),
          });
        });
      }, root);

      cleanup = () => { ctx.revert(); gsap.ticker.remove(tick); lenis.destroy(); };
    })();
    return () => cleanup();
  }, []);

  const go = (href: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    setMenu(false);
    const lenis = (window as unknown as { __lenis?: { scrollTo: (t: string, o?: { offset: number }) => void } }).__lenis;
    if (lenis) lenis.scrollTo(href, { offset: -85 });
    else document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div ref={root}>
      {/* Preloader */}
      <div data-pre className="preloader">
        <span className="font-display text-[clamp(48px,8vw,104px)]">{c.name}</span>
        <span className="text-base"><span data-count>0</span>%</span>
      </div>
      {/* Navbar */}
      <header data-bar className="bar fixed inset-x-0 top-0 z-40 bg-light/85 backdrop-blur-md">
        <span data-progress className="progress" />
        <div className="wrap flex h-[85px] items-center justify-between">
        <a href="#top" onClick={go("#top")} className="font-display text-3xl">{c.name}</a>
        <nav className="hidden gap-7 md:flex">
          {c.nav.map((n) => (
            <a key={n.href} href={n.href} onClick={go(n.href)} className="link-u">{n.label}</a>
          ))}
        </nav>
        <button className="md:hidden link-u" onClick={() => setMenu(true)}>Menú</button></div>
      </header>

      {menu && (
        <div className="fixed inset-0 z-50 flex flex-col bg-accent text-accent-foreground animate-in fade-in duration-300">
          <div className="wrap flex h-[85px] items-center justify-between">
            <span className="font-display text-3xl">{c.name}</span>
            <button onClick={() => setMenu(false)}>Cerrar</button>
          </div>
          <nav className="wrap flex flex-1 flex-col justify-center gap-4">
            {c.nav.map((n, i) => (
              <a key={n.href} href={n.href} onClick={go(n.href)}
                className="font-display text-5xl animate-in slide-in-from-bottom-4 fade-in fill-mode-both duration-500"
                style={{ animationDelay: `${i * 60}ms` }}>
                {n.label}
              </a>
            ))}
          </nav>
        </div>
      )}

      <main id="top">
        {/* 1 · Hero */}
        <section className="bg-fade pb-10 pt-[130px]">
          <div className="wrap grid gap-10 md:grid-cols-12 md:gap-4">
            <div className="flex flex-col items-center justify-center text-center md:col-span-6 md:pr-6">
              <h1 className="h1" data-hero-title data-reveal aria-label={c.name}>
                <span className="line-mask"><span className="inline-block" data-word>{c.name}</span></span>
              </h1>
              <p data-hero-sub className="font-display mt-4 max-w-[18ch] text-[clamp(28px,3.4vw,44px)] leading-[1.12]">{c.tagline}</p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <a data-hero-btn href="#contacto" onClick={go("#contacto")} className="btn">Contáctame</a>
              </div>
              <div data-hero-btn className="mt-6 flex gap-3">
                {c.contact.socials.map((s) => (
                  <a key={s.label} href={s.href} target="_blank" rel="noreferrer" aria-label={s.label} className="icon-btn">
                    {s.icon === "instagram" ? <Instagram className="h-5 w-5" /> : <TikTokIcon />}
                  </a>
                ))}
              </div>
            </div>
            <div className="md:col-span-6">
              <figure data-hero-img className="aspect-[4/5] overflow-hidden">
                <img src={c.heroImage} alt="Retrato de Laura" className="h-full w-full object-cover" />
              </figure>
              <p data-hero-sub className="mt-4 max-w-sm text-base">{c.heroNote}</p>
            </div>
          </div>
        </section>

        {/* 2 · Marcas */}
        <section id="marcas" className="bg-fade-up pb-28">
          <div className="wrap text-center">
            <Reveal text={c.brandsTitle} className="h2 mx-auto max-w-4xl" />
            <div data-stagger className="mx-auto mt-14 grid max-w-5xl grid-cols-3 items-center justify-items-center gap-x-6 gap-y-10 sm:grid-cols-5">
              {c.brands.map((b) => (
                <img key={b.name} src={b.src} alt={b.name} className="brand-logo" loading="lazy" />
              ))}
            </div>
          </div>
        </section>

        {/* Qué hago: nichos y formatos */}
        <section id="que-hago" className="bg-background py-28">
          <div className="wrap">
            <Reveal text={c.servicesTitle} className="h2 mx-auto max-w-3xl text-center" />
            <div data-stagger className="mt-14 grid gap-4 md:grid-cols-3">
              {c.niches.map((n, i) => (
                <div key={n.name} className="niche-card group">
                  <div className="flex items-start justify-between">
                    <span className="niche-num">{String(i + 1).padStart(2, "0")}</span>
                    <span className="niche-arrow" aria-hidden>↗</span>
                  </div>
                  <div>
                    <h3 className="h3">{n.name}</h3>
                    <ul className="mt-4 flex flex-wrap gap-2">
                      {n.examples.split(", ").map((e) => <li key={e} className="niche-tag">{e}</li>)}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
            <div data-stagger className="mt-10 flex flex-wrap justify-center gap-3">
              {c.formats.map((f) => <span key={f} className="chip">{f}</span>)}
            </div>
          </div>
        </section>

        {/* 3 · Contenido */}
        <section id="contenido" className="bg-accent py-28 text-accent-foreground">
          <div className="wrap">
            <Reveal text={c.workTitle} className="h1 text-center" />
            <div data-stagger className="mt-16 grid grid-cols-1 gap-x-4 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
              {c.work.map((w, i) => (
                <article key={w.title} className={i % 3 === 1 ? "lg:mt-20" : ""}>
                  <div className="zoom-card aspect-[9/14]">
                    {w.kind === "video" ? (
                      <video src={w.src} autoPlay muted loop playsInline className="h-full w-full object-cover" />
                    ) : (
                      <img src={w.src} alt={w.title} loading="lazy" className="h-full w-full object-cover" />
                    )}
                  </div>
                  <h3 className="h3 mt-4">{w.title}</h3>
                  <p className="text-base opacity-80">{w.type}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* 4 · Sobre mí: solo texto, grande y centrado */}
        <section id="sobre-mi" className="bg-background py-32 md:py-40">
          <div className="wrap mx-auto max-w-5xl text-center">
            <p className="text-base text-muted-foreground">{c.aboutTitle}</p>
            <p data-scrub className="about-big mt-8">{c.about[0]}</p>
            <p data-scrub className="mx-auto mt-10 max-w-2xl text-[clamp(18px,1.6vw,22px)] leading-snug text-muted-foreground">{c.about[1]}</p>
          </div>
        </section>

        {/* 5 · Testimonios */}
        <section id="testimonios" className="bg-background pb-28">
          <div className="wrap">
            <Reveal text={c.testimonialsTitle} className="h2 text-center" />
            <div data-stagger className="mt-14 grid gap-x-16 gap-y-12 md:grid-cols-2">
              {c.testimonials.map((t) => (
                <figure key={t.company} className="flex gap-5">
                  <img src={t.avatar} alt={t.role} loading="lazy" className="h-16 w-16 shrink-0 rounded-full object-cover" />
                  <div>
                    <blockquote className="max-w-[46ch] text-base">"{t.quote}"</blockquote>
                    <figcaption className="mt-3 text-[23px] leading-tight">
                      — {t.role}
                      <span className="block text-base text-muted-foreground">{t.company}</span>
                    </figcaption>
                  </div>
                </figure>
              ))}
            </div>
          </div>
        </section>

        {/* 6 · Contacto */}
        <section id="contacto" className="bg-accent py-28 text-accent-foreground">
          <div className="wrap">
            <Reveal text={c.contact.title} as="h2" className="h1 mx-auto max-w-4xl text-center" />
            <p className="mx-auto mt-6 max-w-xl text-center">{c.contact.text}</p>
            <div data-stagger className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <a href={`mailto:${c.contact.email}`} className="contact-card sm:col-span-2 lg:col-span-1">
                <Mail className="h-6 w-6 shrink-0" />
                <span className="min-w-0">
                  <span className="block text-sm opacity-70">Email</span>
                  <span className="block truncate text-lg">{c.contact.email}</span>
                </span>
              </a>
              {c.contact.socials.map((s) => (
                <a key={s.label} href={s.href} target="_blank" rel="noreferrer" className="contact-card">
                  {s.icon === "instagram" ? <Instagram className="h-6 w-6 shrink-0" /> : <TikTokIcon />}
                  <span className="min-w-0">
                    <span className="block text-sm opacity-70">{s.label}</span>
                    <span className="block truncate text-lg">{s.handle}</span>
                  </span>
                </a>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-dark py-10 text-paper">
        <div className="wrap flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <p className="font-display text-4xl">{c.name}</p>
          <p className="text-base">{c.footer}</p>
        </div>
      </footer>
    </div>
  );
}

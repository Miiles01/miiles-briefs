# Rotate Display

te toca con rotate porfa, puedes usar esta imagen de header usa la estructura de rotate rifatela porfa.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://rotate-display.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/0bc294c5-5c2a-47dc-a16f-8acc1628f1a6).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

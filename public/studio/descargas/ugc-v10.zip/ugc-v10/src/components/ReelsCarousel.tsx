import { useEffect, useRef, useState } from "react";
import { site } from "@/content/site";

type Reel = (typeof site.reels)[number];

function AutoVideo({ src }: { src: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    const io = new IntersectionObserver(([e]) => (e?.isIntersecting ? v.play().catch(() => {}) : v.pause()), { threshold: 0.4 });
    io.observe(v);
    return () => io.disconnect();
  }, []);
  return <video ref={ref} src={src} muted loop playsInline preload="metadata" className="h-full w-full object-cover" />;
}

export function ReelsCarousel() {
  const track = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState<Reel | null>(null);
  const drag = useRef({ down: false, x: 0, left: 0, moved: false });

  const onScroll = () => {
    const t = track.current;
    if (!t) return;
    const max = t.scrollWidth - t.clientWidth;
    setProgress(max > 0 ? t.scrollLeft / max : 0);
  };
  const step = (dir: number) => {
    const t = track.current;
    if (!t) return;
    const card = t.querySelector("article");
    t.scrollBy({ left: dir * ((card?.clientWidth ?? 300) + 20), behavior: "smooth" });
  };

  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(null);
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open]);

  return (
    <div>
      <div
        ref={track}
        onScroll={onScroll}
        onPointerDown={(e) => {
          if (e.pointerType !== "mouse" || !track.current) return;
          drag.current = { down: true, x: e.clientX, left: track.current.scrollLeft, moved: false };
        }}
        onPointerMove={(e) => {
          const d = drag.current;
          if (!d.down || !track.current) return;
          const dx = e.clientX - d.x;
          if (Math.abs(dx) > 4) d.moved = true;
          track.current.scrollLeft = d.left - dx;
        }}
        onPointerUp={() => (drag.current.down = false)}
        onPointerLeave={() => (drag.current.down = false)}
        className="no-scrollbar wrap flex cursor-grab snap-x snap-mandatory gap-5 overflow-x-auto active:cursor-grabbing"
      >
        {site.reels.map((r) => (
          <article key={r.title} className="reveal-card w-[72vw] shrink-0 snap-start sm:w-[40vw] lg:w-[23vw]">
            <button
              type="button"
              onClick={() => !drag.current.moved && setOpen(r)}
              className="img-zoom block aspect-[9/16] w-full overflow-hidden rounded-lg bg-muted"
              aria-label={`Ver ${r.title}`}
            >
              {r.video ? <AutoVideo src={r.src} /> : <img src={r.src} alt={r.title} loading="lazy" draggable={false} className="h-full w-full object-cover" />}
            </button>
            <div className="mt-3 flex items-baseline justify-between gap-3">
              <h3 className="font-nav text-base">{r.title}</h3>
              <span className="text-sm text-muted-foreground">{r.kind} · {r.tag}</span>
            </div>
          </article>
        ))}
      </div>

      <div className="wrap mt-8 flex items-center gap-6">
        <div className="relative h-[2px] flex-1 overflow-hidden rounded bg-dark/15">
          <div className="absolute inset-y-0 left-0 bg-dark transition-[width] duration-300" style={{ width: `${12 + progress * 88}%` }} />
        </div>
        <div className="flex gap-2">
          <button type="button" onClick={() => step(-1)} className="btn btn-dark !px-5" aria-label="Anterior">←</button>
          <button type="button" onClick={() => step(1)} className="btn btn-dark !px-5" aria-label="Siguiente">→</button>
        </div>
      </div>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setOpen(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-dark/90 p-4 animate-in fade-in duration-300"
        >
          <div onClick={(e) => e.stopPropagation()} className="relative h-[86vh] aspect-[9/16] max-w-full">
            {open.video ? (
              <video src={open.src} controls autoPlay playsInline className="h-full w-full rounded-lg object-cover" />
            ) : (
              <img src={open.src} alt={open.title} className="h-full w-full rounded-lg object-cover" />
            )}
            <button type="button" onClick={() => setOpen(null)} className="btn btn-pink-solid absolute -top-3 -right-3 !px-4 !py-2" aria-label="Cerrar">✕</button>
          </div>
        </div>
      )}
    </div>
  );
}

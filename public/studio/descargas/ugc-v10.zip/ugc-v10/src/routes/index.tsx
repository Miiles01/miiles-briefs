import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { site } from "@/content/site";
import { ReelsCarousel } from "@/components/ReelsCarousel";
import { initMotion, scrollToId } from "@/lib/motion";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Laura · Creadora de contenido UGC" },
      { name: "description", content: site.tagline + "." },
      { property: "og:title", content: "Laura · Creadora de contenido UGC" },
      { property: "og:description", content: site.tagline + "." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Marquee() {
  const items = [...site.marquee, ...site.marquee, ...site.marquee];
  return (
    <div className="flex h-14 items-center overflow-hidden bg-orange" aria-hidden="true">
      <div className="marquee-track flex shrink-0 gap-10 whitespace-nowrap pr-10">
        {[...items, ...items].map((t, i) => (
          <span key={i} className="font-display text-xl font-bold text-pink">
            {t} <span className="text-dark">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function Index() {
  const root = useRef<HTMLDivElement>(null);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    let cleanup: (() => void) | undefined;
    let alive = true;
    if (root.current) initMotion(root.current).then((c) => (alive ? (cleanup = c) : c()));
    return () => {
      alive = false;
      cleanup?.();
    };
  }, []);

  const go = (id: string) => {
    setMenu(false);
    scrollToId(id);
  };

  return (
    <div ref={root}>
      {/* Header: solo hamburguesa, panel desde la derecha */}
      <header className="wrap pointer-events-none fixed inset-x-0 top-0 z-40 flex h-16 items-center justify-between font-nav text-cream">
        <button type="button" onClick={() => go("inicio")} className="pointer-events-auto font-display text-lg font-bold mix-blend-difference">Laura</button>
        <button
          type="button"
          aria-label={menu ? "Cerrar menú" : "Abrir menú"}
          aria-expanded={menu}
          onClick={() => setMenu((m) => !m)}
          className="pointer-events-auto relative z-[60] flex h-12 w-12 items-center justify-center rounded-full bg-cream text-dark transition-transform duration-300 hover:scale-110"
        >
          <span className={`absolute h-0.5 w-5 bg-current transition-transform duration-500 ${menu ? "rotate-45" : "-translate-y-1.5"}`} />
          <span className={`absolute h-0.5 w-5 bg-current transition-opacity duration-300 ${menu ? "opacity-0" : ""}`} />
          <span className={`absolute h-0.5 w-5 bg-current transition-transform duration-500 ${menu ? "-rotate-45" : "translate-y-1.5"}`} />
        </button>
      </header>

      <div
        onClick={() => setMenu(false)}
        className={`fixed inset-0 z-50 bg-dark/60 backdrop-blur-sm transition-opacity duration-500 ${menu ? "opacity-100" : "pointer-events-none opacity-0"}`}
      />
      <aside
        aria-hidden={!menu}
        className={`fixed inset-y-0 right-0 z-50 flex w-[min(86vw,max(50vw,360px))] flex-col bg-dark px-8 pt-24 pb-10 text-cream transition-transform duration-700 ease-[cubic-bezier(0.76,0,0.24,1)] ${menu ? "translate-x-0" : "translate-x-full"}`}
      >
        <button
          type="button"
          onClick={() => setMenu(false)}
          tabIndex={menu ? 0 : -1}
          className="absolute top-4 right-6 flex h-12 items-center gap-2 rounded-full bg-pink px-5 font-nav text-sm font-semibold text-dark transition-transform duration-300 hover:scale-105"
        >
          Cerrar <span aria-hidden="true">✕</span>
        </button>
        <nav className="flex flex-col gap-4">
          {site.nav.map((n, i) => (
            <button
              key={n.id}
              type="button"
              tabIndex={menu ? 0 : -1}
              onClick={() => go(n.id)}
              className={`text-left font-display text-3xl font-bold text-pink transition-all duration-500 hover:translate-x-2 hover:text-orange ${menu ? "translate-x-0 opacity-100" : "translate-x-10 opacity-0"}`}
              style={{ transitionDelay: menu ? `${200 + i * 60}ms` : "0ms" }}
            >
              {n.label}
            </button>
          ))}
        </nav>
        <p className="mt-auto font-nav text-sm text-cream/60">{site.tagline}</p>
      </aside>

      <main>
        {/* 01 Hero */}
        <section id="inicio" className="wrap bg-dark pt-14 pb-20 md:pb-32 text-cream">
          <div className="hero-img relative aspect-[4/5] overflow-hidden rounded-lg sm:aspect-[16/7]">
            <img src={site.heroImage} alt="Laura, creadora de contenido UGC" className="h-[112%] w-full object-cover object-[70%_30%]" />
          </div>
          <h1 data-split className="hero-title h-xl mt-12 text-left text-pink md:mt-20">{site.name}</h1>
          <div className="mt-8 grid gap-8 md:mt-10 md:grid-cols-[1.2fr_1fr] md:items-end">
            <div>
              <p className="hero-fade h-md text-cream">{site.tagline}</p>
              <p className="hero-fade mt-4 max-w-xl text-cream/75">{site.intro}</p>
            </div>
            <div className="flex flex-col gap-5 md:items-end">
              <div className="hero-fade flex flex-wrap gap-3">
                <button type="button" onClick={() => go("contacto")} className="btn btn-pink">Contáctame</button>
              </div>
              <div className="hero-fade flex gap-5 font-nav text-sm text-pink">
                {site.socials.map((s) => (
                  <a key={s.name} href={s.href} target="_blank" rel="noreferrer" className="link-u">{s.name}</a>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* 02 Marcas */}
        <section id="marcas" className="wrap bg-cream py-20 md:py-36">
          <h2 data-split className="h-md">{site.brandsTitle}</h2>
          <div data-stagger className="mt-10 grid grid-cols-3 items-center gap-x-4 gap-y-10 sm:grid-cols-5 sm:gap-x-8">
            {site.brands.map((b) => (
              <img key={b} src={b} alt="" loading="lazy" className="logo-mono mx-auto h-6 w-auto max-w-full object-contain sm:h-8 sm:max-w-[110px]" />
            ))}
          </div>
        </section>

        {/* 03 Contenido */}
        <section id="contenido" className="bg-cream pb-24 md:pb-40">
          <div className="wrap mb-10 flex flex-wrap items-end justify-between gap-4">
            <h2 data-split className="h-lg">Mi contenido</h2>
            <p data-reveal className="max-w-xs text-muted-foreground">Reels y fotos verticales listos para TikTok, Reels o anuncios.</p>
          </div>
          <ReelsCarousel />
        </section>

        <Marquee />

        {/* 04 Nichos — estructura intro de Rotate */}
        <section id="nichos" className="wrap bg-cream py-24 md:py-40">
          <div className="grid gap-16 md:grid-cols-2 md:gap-x-[12%]">
            <div className="flex flex-col gap-8">
              <h2 data-split className="h-md">Nichos en los que trabajo</h2>
              <ul data-stagger className="flex flex-col gap-6">
                {site.niches.map((n) => (
                  <li key={n.t}>
                    <h3 className="font-nav text-lg">{n.t}</h3>
                    <p className="text-muted-foreground">{n.d}</p>
                  </li>
                ))}
              </ul>
              <div data-curtain className="mt-4 hidden aspect-[4/5] w-3/4 overflow-hidden rounded-lg md:block">
                <img src={site.reels[3]!.src} alt="Entrenamiento" loading="lazy" className="h-full w-full object-cover" />
              </div>
            </div>
            <div className="flex flex-col gap-8">
              <div data-curtain className="aspect-[4/5] overflow-hidden rounded-lg">
                <img src={site.heroPortrait} alt="Retrato de Laura" loading="lazy" className="h-full w-full object-cover" />
              </div>
              <h2 data-split className="h-md mt-6">Qué tipo de contenido hago</h2>
              <ul data-stagger className="flex flex-col gap-6">
                {site.contentTypes.map((c, i) => (
                  <li key={c.t} className="grid grid-cols-[2.5rem_1fr] gap-2">
                    <span className="font-display text-sm text-orange">0{i + 1}</span>
                    <div>
                      <h3 className="font-nav text-lg">{c.t}</h3>
                      <p className="text-muted-foreground">Ej.: {c.d}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <h2 data-split className="h-lg mt-24 md:mt-40">Contenido honesto que se siente como la recomendación de una amiga</h2>
        </section>

        {/* Banner a sangre que crece con el scroll */}
        <section className="bg-cream pb-24 md:pb-40">
          <div className="wrap flex flex-col items-start gap-4 pb-8 pt-4 sm:hidden">
            <h2 className="h-lg text-dark">Listo para publicar</h2>
            <button type="button" onClick={() => go("contacto")} className="btn btn-solid">Contáctame</button>
          </div>
          <div className="flex justify-center">
            <div data-grow className="relative mx-auto overflow-hidden rounded-lg">
              <img src={site.ctaImage} alt="Laura sentada en un cubo blanco, lista para grabar" loading="lazy" className="aspect-[4/3] w-full object-cover object-center sm:aspect-[16/9]" />
              <h2 className="h-lg absolute left-[4%] top-[8%] hidden max-w-[15ch] text-white sm:block">Listo para publicar</h2>
              <button type="button" onClick={() => go("contacto")} className="btn btn-pink-solid absolute bottom-[7%] right-[4%] hidden sm:inline-flex">Contáctame</button>
            </div>
          </div>
        </section>

        {/* 05 Sobre mí — founder de Rotate */}
        <section id="sobre-mi" className="wrap grid gap-12 bg-dark py-24 md:py-40 text-cream md:grid-cols-2">
          <div className="flex max-w-md flex-col gap-6">
            <h2 data-split className="h-lg text-pink">Sobre mí</h2>
            {site.about.map((p) => (
              <p data-reveal key={p} className="text-cream/80 text-lg">{p}</p>
            ))}
            <div data-curtain className="mt-6 aspect-[4/5] w-2/3 overflow-hidden rounded-lg">
              <img src={site.aboutImages[1]} alt="Laura en sesión" loading="lazy" className="h-full w-full object-cover" />
            </div>
          </div>
          <div data-curtain className="img-zoom aspect-[3/4] w-full max-w-[520px] justify-self-end overflow-hidden rounded-lg">
            <img data-parallax src={site.aboutImages[0]} alt="Laura" loading="lazy" className="h-[115%] w-full object-cover object-[50%_40%]" />
          </div>
        </section>

        <Marquee />

        {/* 06 Testimonios */}
        <section id="testimonios" className="wrap bg-cream py-24 md:py-40">
          <h2 data-split className="h-lg">Lo que dicen de mí</h2>
          <div data-stagger className="mt-14 grid gap-x-10 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">
            {site.testimonials.map((t) => (
              <figure key={t.c} className="flex flex-col gap-5">
                <blockquote className="text-lg leading-snug">“{t.q}”</blockquote>
                <figcaption className="mt-auto flex items-center gap-3">
                  <img src={t.img} alt="" loading="lazy" className="h-12 w-12 rounded-full object-cover" />
                  <div className="text-sm">
                    <div className="font-nav">{t.r}</div>
                    <div className="text-muted-foreground">{t.c}</div>
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </section>

        {/* 07 Contacto + redes */}
        <section id="contacto" className="wrap bg-dark py-24 md:py-40 text-cream">
          <h2 data-split className="h-lg text-pink">{site.contact.title}</h2>
          <div className="mt-10 grid gap-12 md:grid-cols-2">
            <div data-reveal className="flex flex-col gap-6">
              <p className="max-w-md text-lg text-cream/80">{site.contact.text}</p>
              <a href={`mailto:${site.contact.email}`} className="link-u w-fit max-w-full font-display text-[clamp(14px,4.4vw,22px)] [overflow-wrap:anywhere] md:text-[clamp(13px,1.9vw,24px)]">{site.contact.email}</a>
              <a href={site.contact.whatsapp.href} target="_blank" rel="noreferrer" className="btn btn-pink w-fit">{site.contact.whatsapp.label}</a>
            </div>
            <div data-stagger className="flex flex-col gap-3">
              <h3 className="font-nav text-pink">Mis redes</h3>
              {site.socials.map((s) => (
                <a
                  key={s.name}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  className="group flex items-center justify-between gap-4 rounded-full bg-pink px-7 py-5 text-dark transition-[background-color,padding] duration-500 hover:bg-orange hover:px-9"
                >
                  <span className="font-display text-lg font-bold sm:text-2xl md:text-lg lg:text-2xl">{s.name}</span>
                  <span className="shrink-0 whitespace-nowrap font-nav text-sm">{s.user} <span className="inline-block transition-transform duration-300 group-hover:translate-x-1">→</span></span>
                </a>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Footer Rotate */}
      <footer className="wrap overflow-hidden bg-cream pt-14">
        <div className="grid gap-8 text-sm sm:grid-cols-[2fr_1fr_1fr]">
          <p className="max-w-xs">{site.tagline}.</p>
          <ul className="flex flex-col gap-1">
            {site.nav.map((n) => (
              <li key={n.id}><button type="button" onClick={() => go(n.id)} className="link-u">{n.label}</button></li>
            ))}
          </ul>
          <ul className="flex flex-col gap-1">
            <li><a className="link-u" href={`mailto:${site.contact.email}`}>Email</a></li>
            {site.socials.map((s) => (
              <li key={s.name}><a className="link-u" href={s.href} target="_blank" rel="noreferrer">{s.name}</a></li>
            ))}
          </ul>
        </div>
        <p className="mt-10 text-xs text-muted-foreground">{site.footer}</p>
        <div className="h-xl mt-6 translate-y-[14%] leading-[0.8] text-dark">{site.name}</div>
      </footer>
    </div>
  );
}

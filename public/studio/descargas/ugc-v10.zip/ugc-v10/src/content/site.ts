import heroAsset from "@/assets/hero-laura.jpg.asset.json";
import ctaAsset from "@/assets/listo-para-publicar.jpg.asset.json";

// Todo el contenido de la versión vive aquí: cambia este archivo para crear otra versión.
const M = "https://wearemiiles.com/ugc-v4/media/";

export const site = {
  name: "Laura",
  tagline: "Creadora de contenido UGC para marcas de belleza, moda y bienestar",
  intro:
    "Soy Laura. Hago videos y fotos que se sienten como la recomendación de una amiga: reales, cercanos y pensados para que tu producto se vea en uso.",
  heroImage: heroAsset.url,
  ctaImage: ctaAsset.url,
  portada: M + "portada.jpg",
  heroPortrait: M + "hero.jpg",
  aboutImages: ["/media/sobre-mi-gorra.jpg", M + "foto-2.jpg"],
  nav: [
    { id: "marcas", label: "Marcas" },
    { id: "contenido", label: "Contenido" },
    { id: "nichos", label: "Nichos" },
    { id: "sobre-mi", label: "Sobre mí" },
    { id: "testimonios", label: "Testimonios" },
    { id: "contacto", label: "Contacto" },
  ],
  brandsTitle: "Marcas que confiaron en mí",
  brands: [
    "adidas-13", "chanel-2", "dji-1", "loreal", "la-roche-posay", "samsung-8", "spotify-logo",
    "vichy-laboratoires", "zoah-1", "zara", "vogue", "versace", "pull-bear-2", "bershka-1", "shein",
  ].map((b) => `${M}marcas/${b}.svg`),
  reels: [
    { title: "Rutina de cuidado", kind: "Reel", tag: "Belleza", src: M + "video-1.mp4", video: true },
    { title: "Ropa deportiva", kind: "Foto", tag: "Moda", src: M + "foto-1.jpg" },
    { title: "Primeras impresiones", kind: "Reel", tag: "Lifestyle", src: M + "video-2.mp4", video: true },
    { title: "Entrenamiento", kind: "Foto", tag: "Bienestar", src: M + "foto-2.jpg" },
    { title: "Reseña honesta", kind: "Reel", tag: "Producto", src: M + "video-3.mp4", video: true },
    { title: "Día al aire libre", kind: "Foto", tag: "Lifestyle", src: M + "foto-3.jpg" },
    { title: "Unboxing", kind: "Reel", tag: "Producto", src: M + "video-4.mp4", video: true },
    { title: "Retrato natural", kind: "Foto", tag: "Belleza", src: M + "foto-4.jpg" },
    { title: "Selfie de producto", kind: "Foto", tag: "UGC", src: M + "foto-5.jpg" },
  ],
  niches: [
    { t: "Belleza y skincare", d: "Rutinas, texturas, antes y después y primeras impresiones." },
    { t: "Moda", d: "Try-on hauls, outfits y cómo combinar una prenda." },
    { t: "Bienestar y fitness", d: "Entrenamientos, suplementos y hábitos diarios." },
    { t: "Lifestyle y hogar", d: "Mi día a día, productos en casa y momentos reales." },
  ],
  contentTypes: [
    { t: "Videos UGC para anuncios", d: "Hook en 3 segundos, problema, solución y llamada a la acción." },
    { t: "Unboxing", d: "Abro tu producto y muestro cada detalle por primera vez." },
    { t: "Reseñas y testimoniales", d: "Opinión honesta a cámara, como recomendación de amiga." },
    { t: "Tutoriales", d: "Paso a paso de cómo se usa tu producto." },
    { t: "Fotografía de producto", d: "Fotos lifestyle con el producto en uso." },
  ],
  about: [
    "Me encargo de todo: idea, guion, grabación y edición en formato vertical, listo para publicar en TikTok, Reels o anuncios.",
    "Trabajo con marcas de belleza, moda y bienestar que buscan contenido honesto que genere confianza y ventas.",
  ],
  marquee: ["Contenido real", "Belleza", "Moda", "Bienestar", "Hecho en vertical"],
  testimonials: [
    { q: "Laura entendió la visión de nuestra marca desde el primer momento. El contenido superó nuestras expectativas.", r: "Directora de Marketing", c: "Tech Innovators" },
    { q: "Su capacidad para contar historias a través de la fotografía es única. Cada proyecto es un éxito garantizado.", r: "Fundador", c: "Artisan Coffee Co." },
    { q: "El nivel de atención al detalle que Laura le puso a nuestra última campaña fue increíble.", r: "Directora de Arte", c: "Fashion Forward" },
    { q: "Logró capturar la esencia de lo que somos en cada toma. Es una verdadera profesional.", r: "CEO", c: "Eco Beauty" },
    { q: "Transformó por completo la manera en la que nuestra audiencia nos percibe visualmente.", r: "Brand Manager", c: "Luxe Events" },
    { q: "Una creatividad desbordante y una técnica impecable. Sus fotos hablan por sí solas.", r: "Editor en Jefe", c: "Revista Estilo" },
  ].map((t, i) => ({ ...t, img: `${M}testimonios/persona-${i + 1}.jpg` })),
  contact: {
    title: "Hagamos algo juntas",
    text: "Cuéntame de tu marca y de lo que necesitas. Te respondo en menos de 24 horas.",
    email: "hola@lauracreativa.com",
    whatsapp: { label: "Escríbeme directo", href: "https://wa.me/" },
  },
  socials: [
    { name: "Instagram", user: "@laura.ugc", href: "https://instagram.com" },
    { name: "TikTok", user: "@laura.ugc", href: "https://tiktok.com" },
    { name: "YouTube", user: "@laura.ugc", href: "https://youtube.com" },
  ],
  footer: "© 2026 Laura · Plantilla UGC de We Are Miiles",
};

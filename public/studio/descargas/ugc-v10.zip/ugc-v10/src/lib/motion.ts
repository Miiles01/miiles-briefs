// Animaciones del home: Lenis + GSAP ScrollTrigger. Solo en el navegador.
export async function initMotion(root: HTMLElement) {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return () => {};
  const [{ gsap }, { ScrollTrigger }, { default: Lenis }] = await Promise.all([
    import("gsap"),
    import("gsap/ScrollTrigger"),
    import("lenis"),
  ]);
  gsap.registerPlugin(ScrollTrigger);
  const ease = "power3.out";

  const lenis = new Lenis({ lerp: 0.08, wheelMultiplier: 0.9, smoothWheel: true });
  lenis.on("scroll", ScrollTrigger.update);
  const tick = (t: number) => lenis.raf(t * 1000);
  gsap.ticker.add(tick);
  gsap.ticker.lagSmoothing(0);
  (window as unknown as { __lenis?: unknown }).__lenis = lenis;

  // Partir títulos en palabras con máscara
  root.querySelectorAll<HTMLElement>("[data-split]:not(.hero-title)").forEach((el) => {
    if (el.dataset["done"]) return;
    el.dataset["done"] = "1";
    const words = (el.textContent ?? "").trim().split(/\s+/);
    el.innerHTML = words.map((w) => `<span class="mask-line"><span>${w}</span></span>`).join(" ");
  });

  const ctx = gsap.context(() => {
    // La entrada del hero va en CSS (styles.css): arranca con el primer pintado y no parpadea al hidratar

    gsap.to(".hero-img img", { yPercent: 12, ease: "none", scrollTrigger: { trigger: ".hero-img", start: "top top", end: "bottom top", scrub: true } });

    gsap.utils.toArray<HTMLElement>("[data-split]:not(.hero-title)").forEach((el) => {
      gsap.from(el.querySelectorAll(".mask-line > span"), {
        yPercent: 110, duration: 0.9, ease, stagger: 0.04,
        scrollTrigger: { trigger: el, start: "top 88%" },
      });
    });

    gsap.utils.toArray<HTMLElement>("[data-reveal]").forEach((el) => {
      gsap.from(el, { y: 32, opacity: 0, duration: 0.8, ease, scrollTrigger: { trigger: el, start: "top 90%" } });
    });

    gsap.utils.toArray<HTMLElement>("[data-stagger]").forEach((el) => {
      gsap.from(el.children, { y: 28, opacity: 0, duration: 0.7, ease, stagger: 0.06, scrollTrigger: { trigger: el, start: "top 88%" } });
    });

    gsap.utils.toArray<HTMLElement>("[data-curtain]").forEach((el) => {
      gsap.from(el, { opacity: 0, duration: 1.2, ease, scrollTrigger: { trigger: el, start: "top 85%" } });
      const m = el.querySelector("img");
      if (m) gsap.from(m, { scale: 1.15, duration: 1.6, ease, scrollTrigger: { trigger: el, start: "top 85%" } });
    });

    gsap.utils.toArray<HTMLElement>("[data-grow]").forEach((el) => {
      gsap.fromTo(el, { width: "50%" }, { width: "100%", ease: "none", scrollTrigger: { trigger: el, start: "top 95%", end: "center 55%", scrub: true } });
    });

    gsap.utils.toArray<HTMLElement>("[data-parallax]").forEach((el) => {
      gsap.to(el, { yPercent: -10, ease: "none", scrollTrigger: { trigger: el, start: "top bottom", end: "bottom top", scrub: true } });
    });
    // Fades suaves para textos, listas e imágenes sin animación propia
    gsap.utils.toArray<HTMLElement>("section p:not([data-reveal]), section img:not(.hero-img img)").forEach((el) => {
      if (el.closest("#inicio,[data-reveal],[data-stagger],[data-curtain],[data-grow],[data-split],[data-parallax],.hero-img,.hero-fade") || el.matches("[data-parallax]")) return;
      gsap.from(el, { y: 20, opacity: 0, duration: 0.9, ease, scrollTrigger: { trigger: el, start: "top 92%" } });
    });

    // Secciones oscuras: leve escala de entrada
    gsap.utils.toArray<HTMLElement>("section.bg-dark:not(#inicio)").forEach((el) => {
      gsap.from(el, { opacity: 0.6, ease: "none", scrollTrigger: { trigger: el, start: "top bottom", end: "top 60%", scrub: true } });
    });

    // Títulos grandes con leve deriva al hacer scroll
    gsap.utils.toArray<HTMLElement>(".h-lg").forEach((el) => {
      gsap.fromTo(el, { x: 30 }, { x: -10, ease: "none", scrollTrigger: { trigger: el, start: "top bottom", end: "bottom top", scrub: true } });
    });

    requestAnimationFrame(() => ScrollTrigger.refresh());
  }, root);

  return () => {
    ctx.revert();
    gsap.ticker.remove(tick);
    lenis.destroy();
  };
}

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  const l = (window as unknown as { __lenis?: { scrollTo: (e: Element, o?: object) => void } }).__lenis;
  if (l) l.scrollTo(el, { offset: -10 });
  else el.scrollIntoView({ behavior: "smooth" });
}

# Pulido final v6
- [x] Ajustar legibilidad, espaciado y estados de botones conservando Ortiz.
- [x] Pulir menú, carrusel y visor con teclado y movimiento reducido.
- [x] Verificar imágenes, navegación y tamaños del brief.
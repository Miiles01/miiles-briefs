<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- All portfolio copy, media URLs and links live in src/content/site.ts so new template versions only swap that file.
- Use PortfolioDialog for full-screen navigation and media viewers so focus trapping, Escape and scroll locking stay consistent.
- Portfolio controls use the portfolio Button variants so shared focus and disabled states preserve the Ortiz styling.
- Video poster pointers are imported by site.ts; use actual video frames so previews stay visible before playback is available.

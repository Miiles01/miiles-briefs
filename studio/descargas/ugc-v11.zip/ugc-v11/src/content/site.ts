// Todo el contenido del portafolio. Para otra versión, cambia solo este archivo.
// Versión 6 (Ortiz). Las fotos y videos siguen en la carpeta v4: en el servidor no existe una carpeta v6.
import poster1 from "@/assets/poster-1.jpg.asset.json";
import poster2 from "@/assets/poster-2.jpg.asset.json";
import poster3 from "@/assets/poster-3.jpg.asset.json";
import poster4 from "@/assets/poster-4.jpg.asset.json";
import portada from "@/assets/portada.jpg.asset.json";

const VERSION = 6;
const M = "https://wearemiiles.com/ugc-v4/media/";

export const site = {
  version: VERSION,
  ui: { menu: "Menú", close: "Cerrar", previous: "Anterior", next: "Siguiente", work: "Ver mi trabajo", contact: "Contáctame", about: "Sobre mí", together: "Trabajemos juntas", socials: "Mis redes", example: "Ej.:", home: "Volver al inicio" },
  contentHeading: "Reels y fotos que se ven como de una amiga",
  nichesTitle: "Nichos en los que trabajo",
  formatsTitle: "Qué tipo de contenido hago",
  name: "Laura",
  role: "Creadora de contenido UGC para marcas de belleza, moda y bienestar",
  intro:
    "Soy Laura. Hago videos y fotos que se sienten como la recomendación de una amiga: reales, cercanos y pensados para que tu producto se vea en uso.",
  media: {
    hero: M + "hero.jpg",
    cover: "/media/portada.jpg", // mismo retrato, alojado en el proyecto
    about: "/media/sobre-mi.jpg", // recorte 4:5 centrado en Laura
  },
  nav: [
    { id: "marcas", label: "Marcas" },
    { id: "contenido", label: "Contenido" },
    { id: "nichos", label: "Nichos" },
    { id: "sobre-mi", label: "Sobre mí" },
    { id: "testimonios", label: "Testimonios" },
    { id: "contacto", label: "Contacto" },
  ],
  brandsTitle: "Marcas que confiaron en mí",
  brands: [
    "adidas-13", "chanel-2", "dji-1", "loreal", "la-roche-posay", "samsung-8", "spotify-logo",
    "vichy-laboratoires", "zoah-1", "zara", "vogue", "versace", "pull-bear-2", "bershka-1", "shein",
  ].map((b) => ({ name: b, src: `/marcas/${b}.svg` })),
  contentTitle: "Mi trabajo",
  reels: [
    { title: "Rutina de cuidado", kind: "Reel", tag: "Belleza", src: M + "video-1.mp4", video: true, poster: poster1.url },
    { title: "Ropa deportiva", kind: "Foto", tag: "Moda", src: M + "foto-1.jpg", video: false },
    { title: "Primeras impresiones", kind: "Reel", tag: "Lifestyle", src: M + "video-2.mp4", video: true, poster: poster2.url },
    { title: "Entrenamiento", kind: "Foto", tag: "Bienestar", src: M + "foto-2.jpg", video: false },
    { title: "Reseña honesta", kind: "Reel", tag: "Producto", src: M + "video-3.mp4", video: true, poster: poster3.url },
    { title: "Día al aire libre", kind: "Foto", tag: "Lifestyle", src: M + "foto-3.jpg", video: false },
    { title: "Unboxing", kind: "Reel", tag: "Producto", src: M + "video-4.mp4", video: true, poster: poster4.url },
    { title: "Retrato natural", kind: "Foto", tag: "Belleza", src: M + "foto-4.jpg", video: false },
    { title: "Selfie de producto", kind: "Foto", tag: "UGC", src: M + "foto-5.jpg", video: false },
  ],
  niches: [
    { title: "Belleza y skincare", text: "Rutinas, texturas, antes y después y primeras impresiones." },
    { title: "Moda", text: "Try-on hauls, outfits y cómo combinar una prenda." },
    { title: "Bienestar y fitness", text: "Entrenamientos, suplementos y hábitos diarios." },
    { title: "Lifestyle y hogar", text: "Mi día a día, productos en casa y momentos reales." },
  ],
  formats: [
    { title: "Videos UGC para anuncios", example: "Hook en 3 segundos, problema, solución y llamada a la acción." },
    { title: "Unboxing", example: "Abro tu producto y muestro cada detalle por primera vez." },
    { title: "Reseñas y testimoniales", example: "Opinión honesta a cámara, como recomendación de amiga." },
    { title: "Tutoriales", example: "Paso a paso de cómo se usa tu producto." },
    { title: "Fotografía de producto", example: "Fotos lifestyle con el producto en uso." },
  ],
  about: [
    "Me encargo de todo: idea, guion, grabación y edición en formato vertical, listo para publicar en TikTok, Reels o anuncios.",
    "Trabajo con marcas de belleza, moda y bienestar que buscan contenido honesto que genere confianza y ventas.",
  ] as const,
  testimonialsTitle: "Lo que dicen de mí",
  testimonials: [
    ["Laura entendió la visión de nuestra marca desde el primer momento. El contenido superó nuestras expectativas.", "Directora de Marketing", "Tech Innovators"],
    ["Su capacidad para contar historias a través de la fotografía es única. Cada proyecto es un éxito garantizado.", "Fundador", "Artisan Coffee Co."],
    ["El nivel de atención al detalle que Laura le puso a nuestra última campaña fue increíble.", "Directora de Arte", "Fashion Forward"],
    ["Logró capturar la esencia de lo que somos en cada toma. Es una verdadera profesional.", "CEO", "Eco Beauty"],
    ["Transformó por completo la manera en la que nuestra audiencia nos percibe visualmente.", "Brand Manager", "Luxe Events"],
    ["Una creatividad desbordante y una técnica impecable. Sus fotos hablan por sí solas.", "Editor en Jefe", "Revista Estilo"],
  ].map(([quote, role, company], i) => ({ quote, role, company, avatar: `${M}testimonios/persona-${i + 1}.jpg` })),
  contact: {
    title: "Hagamos algo juntas",
    text: "Cuéntame de tu marca y de lo que necesitas. Te respondo en menos de 24 horas.",
    email: "hola@lauracreativa.com",
    whatsapp: { label: "Escríbeme directo", href: "https://wa.me/" },
  },
  socials: [
    { name: "Instagram", handle: "@laura.ugc", href: "https://instagram.com" },
    { name: "TikTok", handle: "@laura.ugc", href: "https://tiktok.com" },
    { name: "YouTube", handle: "@laura.ugc", href: "https://youtube.com" },
  ],
  footer: `© 2026 Laura · Plantilla UGC v${VERSION} de We Are Miiles`,
};

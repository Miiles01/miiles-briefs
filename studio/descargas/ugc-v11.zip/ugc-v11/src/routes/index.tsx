import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import Lenis from "lenis";
import { Instagram, Music2, Youtube, MessageCircle, Mail, ArrowUpRight } from "lucide-react";
import { site } from "@/content/site";
import { SplitText, Reveal, Curtain } from "@/components/motion";
import { ReelCarousel } from "@/components/ReelCarousel";
import { Button } from "@/components/ui/button";
import { PortfolioDialog } from "@/components/PortfolioDialog";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${site.name} · Creadora de contenido UGC` },
      { name: "description", content: site.role },
      { property: "og:title", content: `${site.name} · Creadora de contenido UGC` },
      { property: "og:description", content: site.intro },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: site.media.hero },
      { name: "twitter:image", content: site.media.hero },
    ],
  }),
  component: Index,
});

const icons: Record<string, typeof Instagram | undefined> = { Instagram, TikTok: Music2, YouTube: Youtube };

let lenisRef: Lenis | null = null;
function goTo(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  if (lenisRef) lenisRef.scrollTo(el, { offset: -20 });
  else el.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
}

function Header() {
  const [open, setOpen] = useState(false);
  // Se oculta al bajar y vuelve a aparecer al subir
  const [hidden, setHidden] = useState(false);
  useEffect(() => {
    let last = window.scrollY;
    const on = () => {
      const y = window.scrollY;
      if (Math.abs(y - last) < 6) return;
      setHidden(y > last && y > 120);
      last = y;
    };
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <header className={`fixed inset-x-0 top-0 z-40 bg-background/85 backdrop-blur-md transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${hidden && !open ? "-translate-y-full" : "translate-y-0"}`}>
      <div className="flex h-[88px] items-center justify-between gap-6 px-[6vw]">
        <Button variant="portfolioPlain" size="natural" onClick={() => goTo("inicio")} className="font-display text-xl" aria-label={site.ui.home}>{site.name}</Button>
        <nav className="hidden items-center gap-6 xl:flex">
          {site.nav.map((n) => <a key={n.id} href={`#${n.id}`} onClick={(e) => { e.preventDefault(); goTo(n.id); }} className="relative after:absolute after:-bottom-1 after:left-0 after:h-px after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full">{n.label}</a>)}
        </nav>
        <Button variant="portfolio" size="natural" onClick={() => goTo("contacto")} className="hidden !py-2.5 xl:inline-flex">{site.ui.contact}</Button>
        <Button variant="portfolio" size="natural" onClick={() => setOpen(true)} className="!py-2.5 xl:hidden" aria-expanded={open} aria-haspopup="dialog">{site.ui.menu}</Button>
      </div>
      <PortfolioDialog open={open} onOpenChange={setOpen} title={site.ui.menu} menu>
        <div className="flex h-[88px] items-center"><span className="font-display text-xl">{site.name}</span></div>
        <nav className="mt-6 flex flex-col gap-3">
          {site.nav.map((n) => <a key={n.id} href={`#${n.id}`} onClick={(e) => { e.preventDefault(); setOpen(false); setTimeout(() => goTo(n.id), 80); }} className="w-fit font-display text-4xl leading-snug transition-opacity hover:opacity-70 lg:text-5xl">{n.label}</a>)}
        </nav>
      </PortfolioDialog>
    </header>
  );
}

function Socials({ className = "" }: { className?: string }) {
  return (
    <div className={`flex gap-3 ${className}`}>
      {site.socials.map((s) => {
        const I = icons[s.name];
        if (!I) return null;
        return (
          <Button asChild variant="portfolioIcon" size="natural" key={s.name}><a href={s.href} target="_blank" rel="noreferrer noopener" aria-label={s.name}>
            <I className="h-5 w-5" />
          </a></Button>
        );
      })}
    </div>
  );
}

function Hero() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setReady(true), 80);
    return () => clearTimeout(t);
  }, []);
  return (
    <section id="inicio" className={`grid hero-section md:grid-cols-2 ${ready ? "is-in" : ""}`}>
      <div className="hero-copy flex flex-col px-[6vw] pt-[120px] pb-12 md:pr-8">
        <h1 className="hero-name font-display-tight" aria-label={site.name}>
          {site.name.split("").map((c, i) => (
            <span key={i} aria-hidden className="mask-word !p-0 !m-0 !pb-[0.12em]">
              <span style={{ ["--d" as string]: `${i * 70}ms` }}>{c}</span>
            </span>
          ))}
        </h1>
        <div className="mt-8 max-w-md md:mt-auto">
          <p className="reveal font-display text-2xl leading-snug md:text-3xl" style={{ ["--d" as string]: "450ms" }}>
            {site.role}
          </p>
          <p className="reveal mt-5 text-muted-foreground" style={{ ["--d" as string]: "600ms" }}>
            {site.intro}
          </p>
          <div className="reveal mt-8 flex flex-wrap gap-3" style={{ ["--d" as string]: "750ms" }}>
            <Button variant="portfolio" size="natural" onClick={() => goTo("contacto")}>{site.ui.contact}</Button>
          </div>
          <Socials className="reveal mt-6 [--d:900ms]" />
        </div>
      </div>
      <div className="relative bg-sun md:pt-[88px]">
        <div className="curtain hero-photo w-full [transition-delay:300ms]">
          <img src={site.media.hero} fetchPriority="high" alt={`Retrato de ${site.name}`} className="blob h-full w-full object-cover p-3 md:p-4" />
        </div>
      </div>
    </section>
  );
}

function Brands() {
  const list = [...site.brands, ...site.brands];
  return (
    <section id="marcas" className="py-24">
      <div className="px-[6vw]">
        <SplitText text={site.brandsTitle} className="section-title font-display-tight" />
      </div>
      <Reveal className="mt-14 overflow-hidden">
        <div className="marquee flex w-max items-center gap-16">
          {list.map((b, i) => (
            <span
              key={i}
              role="img" aria-label={b.name} aria-hidden={i >= site.brands.length}
              className="block h-10 w-32 bg-primary opacity-80 transition-opacity hover:opacity-100"
              style={{
                mask: `url(${b.src}) center / contain no-repeat`,
                WebkitMask: `url(${b.src}) center / contain no-repeat`,
              }}
            />
          ))}
        </div>
      </Reveal>
    </section>
  );
}

function Cover() {
  const ref = useRef<HTMLDivElement>(null);
  const [p, setP] = useState(0);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setP(1); return; }
    const on = () => {
      const el = ref.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const v = 1 - (r.top - window.innerHeight * 0.2) / (window.innerHeight * 0.8);
      setP(Math.min(1, Math.max(0, v)));
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <div ref={ref} className="flex justify-center py-8">
      <div
        className="aspect-[16/9] overflow-hidden rounded-[2rem]"
        style={{ width: `${50 + p * 50}%`, borderRadius: `${(1 - p) * 2}rem` }}
      >
        <img src={site.media.cover} alt={`Retrato de ${site.name}`} className="h-full w-full object-cover object-[50%_18%]" style={{ transform: `scale(${1.08 - p * 0.08})`, transformOrigin: "50% 20%" }} />
      </div>
    </div>
  );
}

function Content() {
  return (
    <section id="contenido" className="py-24">
      <div className="mb-14 grid gap-6 px-[6vw] md:grid-cols-[1fr_2fr]">
        <Reveal className="text-lg">{site.contentTitle}</Reveal>
        <SplitText text={site.contentHeading} className="section-title font-display-tight" />
      </div>
      <ReelCarousel />
    </section>
  );
}

function Niches() {
  return (
    <section id="nichos" className="bg-secondary py-28">
      <div className="grid gap-16 px-[6vw] lg:grid-cols-2">
        <div>
          <SplitText text={site.nichesTitle} className="niche-title font-display-tight" />
          <div className="mt-10 grid gap-8">
            {site.niches.map((n, i) => (
              <Reveal key={n.title} delay={i * 80}>
                <h3 className="font-display text-2xl">{n.title}</h3>
                <p className="mt-1 text-muted-foreground">{n.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
        <div>
          <SplitText text={site.formatsTitle} className="niche-title font-display-tight" />
          <div className="mt-10 grid gap-4">
            {site.formats.map((f, i) => (
              <Reveal key={f.title} delay={i * 80} className="rounded-3xl bg-background p-6">
                <h3 className="font-display text-2xl">{f.title}</h3>
                <p className="mt-2 text-muted-foreground">
                  <span className="text-foreground">{site.ui.example}</span> {f.example}
                </p>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="sobre-mi" className="grid min-h-[90vh] md:grid-cols-2">
      <Curtain className="h-[70vh] md:h-auto">
        <img src={site.media.about} alt={`${site.name} sonriendo`} className="h-full w-full object-cover object-[50%_30%]" />
      </Curtain>
      <div className="flex flex-col justify-center px-[6vw] py-20 md:pl-16">
        <Reveal className="text-lg">{site.ui.about}</Reveal>
        <SplitText text={site.about[0]} className="mt-6 about-title font-display-tight !leading-[1.2]" step={25} />
        <Reveal delay={200} className="mt-8 max-w-lg text-lg text-muted-foreground">
          {site.about[1]}
        </Reveal>
        <Reveal delay={300} className="mt-10">
          <Button variant="portfolio" size="natural" onClick={() => goTo("contacto")}>{site.ui.together}</Button>
        </Reveal>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section id="testimonios" className="px-[6vw] py-28">
      <SplitText text={site.testimonialsTitle} className="text-center section-title font-display-tight" />
      <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {site.testimonials.map((t, i) => (
          <Reveal key={i} delay={(i % 3) * 100} className="flex flex-col rounded-[2rem] bg-card p-8">
            <p className="font-display text-xl leading-snug">“{t.quote}”</p>
            <div className="mt-auto flex items-center gap-4 pt-8">
              <img src={t.avatar} alt="" loading="lazy" className="h-12 w-12 rounded-full object-cover" />
              <div className="text-sm">
                <p>{t.role}</p>
                <p className="text-muted-foreground">{t.company}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Contact() {
  const words = Array(4).fill(site.contact.title);
  return (
    <section id="contacto" className="overflow-hidden bg-secondary py-24">
      <div className="marquee flex w-max contact-title font-display-tight !leading-[1.25]">
        {words.map((w, i) => (
          <span key={i} aria-hidden={i > 0} className="pr-[0.5em]">{w}</span>
        ))}
      </div>
      <div className="mx-auto mt-10 max-w-3xl px-[6vw] text-center">
        <Reveal className="text-lg text-muted-foreground">{site.contact.text}</Reveal>
        <Reveal delay={100} className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild variant="portfolioSolid" size="natural"><a href={`mailto:${site.contact.email}`}>
            <Mail className="h-4 w-4" /> {site.contact.email}
          </a></Button>
          <Button asChild variant="portfolio" size="natural"><a href={site.contact.whatsapp.href} target="_blank" rel="noreferrer noopener">
            <MessageCircle className="h-4 w-4" /> {site.contact.whatsapp.label}
          </a></Button>
        </Reveal>
      </div>
      <div className="mt-16 px-[6vw]">
        <Reveal className="mb-6 text-center text-lg">{site.ui.socials}</Reveal>
        <div className="mx-auto grid max-w-5xl gap-4 md:grid-cols-3">
          {site.socials.map((s, i) => {
            const I = icons[s.name];
            if (!I) return null;
            return (
              <Reveal key={s.name} delay={i * 100}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="group flex min-w-0 gap-3 items-center justify-between rounded-[2rem] bg-primary p-7 text-primary-foreground transition-transform duration-300 hover:-translate-y-1"
                >
                  <span className="flex min-w-0 items-center gap-4">
                    <I className="h-8 w-8" />
                    <span>
                      <span className="block font-display text-2xl">{s.name}</span>
                      <span className="break-all text-sm opacity-80">{s.handle}</span>
                    </span>
                  </span>
                  <ArrowUpRight className="h-6 w-6 transition-transform duration-300 group-hover:rotate-45" />
                </a>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Index() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const lenis = new Lenis({ duration: 1.1 });
    lenisRef = lenis;
    let id = 0;
    const raf = (t: number) => {
      lenis.raf(t);
      id = requestAnimationFrame(raf);
    };
    id = requestAnimationFrame(raf);
    return () => {
      cancelAnimationFrame(id);
      lenis.destroy();
      lenisRef = null;
    };
  }, []);

  return (
    <div className="relative">
      <Header />
      <main>
        <Hero />
        <Brands />
        <Cover />
        <Content />
        <Niches />
        <About />
        <Testimonials />
        <Contact />
      </main>
      <footer className="bg-primary px-[6vw] py-10 text-sm text-primary-foreground">{site.footer}</footer>
    </div>
  );
}

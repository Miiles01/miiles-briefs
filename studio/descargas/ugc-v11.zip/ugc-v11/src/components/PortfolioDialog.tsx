import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { site } from "@/content/site";

export function PortfolioDialog({ open, onOpenChange, title, children, menu = false }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  children: ReactNode;
  menu?: boolean;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        {/* Menú: panel a media pantalla desde la derecha; el resto de la página se oscurece */}
        <Dialog.Overlay className={`fixed inset-0 z-[60] data-[state=open]:animate-in data-[state=open]:fade-in data-[state=closed]:animate-out data-[state=closed]:fade-out duration-300 ${menu ? "bg-black/45" : "bg-primary"}`} />
        <Dialog.Content aria-describedby={undefined} data-lenis-prevent className={`fixed z-[61] text-primary-foreground outline-none ${menu ? "inset-y-0 right-0 w-[min(86vw,max(50vw,360px))] overflow-y-auto bg-primary px-8 pb-8 sm:px-12 data-[state=open]:animate-in data-[state=open]:slide-in-from-right data-[state=closed]:animate-out data-[state=closed]:slide-out-to-right duration-500" : "left-1/2 top-1/2 w-fit max-w-[calc(100vw-2rem)] -translate-x-1/2 -translate-y-1/2"}`}>
          <Dialog.Title className="sr-only">{title}</Dialog.Title>
          {children}
          <Dialog.Close asChild>
            {menu ? (
              <button type="button" className="menu-close absolute right-8 top-6 z-10 inline-flex items-center gap-2 whitespace-nowrap rounded-full bg-primary-foreground px-5 py-2.5 text-sm font-semibold text-primary transition-transform hover:scale-105 sm:right-12" aria-label={site.ui.close}>
                {site.ui.close} <X aria-hidden className="h-4 w-4" />
              </button>
            ) : (
              <Button variant="portfolioPlain" size="icon" className="dialog-close fixed -right-2 -top-14" aria-label={site.ui.close} title={site.ui.close}>
                <X aria-hidden className="!h-6 !w-6" />
              </Button>
            )}
          </Dialog.Close>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
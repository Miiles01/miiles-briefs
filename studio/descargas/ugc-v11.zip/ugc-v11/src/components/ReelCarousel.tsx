import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Play } from "lucide-react";
import { site } from "@/content/site";
import { Button } from "@/components/ui/button";
import { PortfolioDialog } from "@/components/PortfolioDialog";

type Reel = (typeof site.reels)[number];

function AutoVideo({ src, poster, paused }: { src: string; poster: string | undefined; paused: boolean }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    if (paused || window.matchMedia("(prefers-reduced-motion: reduce)").matches) { video.pause(); return; }
    let visible = false;
    const update = () => {
      if (visible && !document.hidden) video.play().catch(() => {});
      else video.pause();
    };
    const observer = new IntersectionObserver(([entry]) => { visible = entry?.isIntersecting ?? false; update(); }, { threshold: 0.5 });
    observer.observe(video);
    document.addEventListener("visibilitychange", update);
    return () => { observer.disconnect(); video.pause(); document.removeEventListener("visibilitychange", update); };
  }, [paused]);
  return <video ref={ref} src={src} poster={poster} muted loop playsInline preload="none" className="h-full w-full object-cover" />;
}

export function ReelCarousel() {
  const track = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLElement | null>(null);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState<Reel | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const drag = useRef({ down: false, x: 0, left: 0, moved: false });

  const onScroll = () => {
    const element = track.current;
    if (!element) return;
    const max = element.scrollWidth - element.clientWidth;
    setProgress(max > 0 ? Math.max(0, Math.min(1, element.scrollLeft / max)) : 0);
    setHasMore(max > 1);
  };
  useEffect(() => {
    const element = track.current;
    if (!element) return;
    const observer = new ResizeObserver(onScroll);
    observer.observe(element);
    onScroll();
    return () => observer.disconnect();
  }, []);
  const move = (direction: number) => {
    const element = track.current;
    const card = element?.firstElementChild;
    if (!element || !card) return;
    const gap = parseFloat(getComputedStyle(element).gap) || 20;
    element.scrollBy({ left: direction * (card.getBoundingClientRect().width + gap), behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  };

  return (
    <div>
      <div
        ref={track}
        onScroll={onScroll}
        data-lenis-prevent-wheel
        onPointerDown={(event) => {
          drag.current.moved = false;
          if (event.pointerType !== "mouse" || !track.current) return;
          drag.current = { down: true, x: event.clientX, left: track.current.scrollLeft, moved: false };
        }}
        onPointerMove={(event) => {
          const state = drag.current;
          if (!state.down || !track.current) return;
          const delta = event.clientX - state.x;
          if (Math.abs(delta) > 5) state.moved = true;
          track.current.scrollLeft = state.left - delta;
        }}
        onPointerUp={() => { drag.current.down = false; }}
        onPointerCancel={() => { drag.current.down = false; drag.current.moved = false; }}
        onPointerLeave={() => { drag.current.down = false; }}
        className="flex cursor-grab snap-x gap-5 overflow-x-auto px-[6vw] pt-2 pb-2 select-none active:cursor-grabbing [scroll-padding-inline:6vw] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {site.reels.map((reel) => (
          <Button
            variant="portfolioPlain" size="natural"
            key={reel.title}
            aria-haspopup="dialog"
            onClick={(event) => {
              if (drag.current.moved && event.detail !== 0) { drag.current.moved = false; return; }
              trigger.current = event.currentTarget;
              setOpen(reel);
            }}
            className="group !block w-[68vw] shrink-0 snap-start text-left sm:w-[38vw] lg:w-[22vw] lg:max-w-[320px]"
          >
            <div className="hover-zoom relative aspect-[9/16] rounded-[2rem] bg-muted">
              {reel.video ? <AutoVideo src={reel.src} poster={reel.poster} paused={open !== null} /> : <img src={reel.src} alt={reel.title} loading="lazy" draggable={false} className="h-full w-full object-cover" />}
              {reel.video && <span aria-hidden className="absolute bottom-4 left-4 flex h-10 w-10 items-center justify-center rounded-full bg-background text-primary"><Play className="!h-4 !w-4 fill-current" /></span>}
            </div>
            <span className="mt-4 block font-display text-xl">{reel.title}</span>
            <span className="block text-sm text-muted-foreground">{reel.kind} · {reel.tag}</span>
          </Button>
        ))}
      </div>
      <div className="mx-[6vw] mt-8 flex items-center gap-4 sm:gap-6">
        <div className="relative h-[2px] flex-1 overflow-hidden rounded-full bg-border" aria-hidden>
          <div className="absolute inset-y-0 left-0 rounded-full bg-primary transition-[width] duration-300" style={{ width: `${12 + progress * 88}%` }} />
        </div>
        <Button variant="portfolioIcon" size="natural" onClick={() => move(-1)} disabled={progress <= 0.001} aria-label={site.ui.previous} title={site.ui.previous}><ArrowLeft className="!h-5 !w-5" /></Button>
        <Button variant="portfolioIcon" size="natural" onClick={() => move(1)} disabled={!hasMore || progress >= 0.999} aria-label={site.ui.next} title={site.ui.next}><ArrowRight className="!h-5 !w-5" /></Button>
      </div>
      <PortfolioDialog open={open !== null} onOpenChange={(value) => { if (!value) { setOpen(null); requestAnimationFrame(() => trigger.current?.focus({ preventScroll: true })); } }} title={open?.title ?? site.contentTitle}>
        {open && <div className="viewer-media">
          {open.video ? <video src={open.src} poster={open.poster} controls autoPlay playsInline className="h-full w-full rounded-3xl object-contain" /> : <img src={open.src} alt={open.title} className="h-full w-full rounded-3xl object-contain" />}
        </div>}
      </PortfolioDialog>
    </div>
  );
}

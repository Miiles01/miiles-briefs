import { useEffect, useRef, type ElementType, type ReactNode } from "react";

/** Añade .is-in cuando el elemento entra en pantalla. */
export function useInView<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e?.isIntersecting) {
          el.classList.add("is-in");
          io.disconnect();
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -8% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return ref;
}

export function SplitText({
  text,
  as: Tag = "h2",
  className,
  delay = 0,
  step = 60,
}: {
  text: string;
  as?: ElementType;
  className?: string;
  delay?: number;
  step?: number;
}) {
  const ref = useInView<HTMLElement>();
  const words = text.split(" ");
  return (
    <Tag ref={ref} className={className} aria-label={text}>
      {words.map((w, i) => (
        <span key={i} aria-hidden className="mask-word">
          <span style={{ ["--d" as string]: `${delay + i * step}ms` }}>{w}</span>
          {i < words.length - 1 ? "\u00a0" : ""}
        </span>
      ))}
    </Tag>
  );
}

export function Reveal({
  children,
  className = "",
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: ElementType;
}) {
  const ref = useInView<HTMLElement>();
  return (
    <Tag ref={ref} className={`reveal ${className}`} style={{ ["--d" as string]: `${delay}ms` }}>
      {children}
    </Tag>
  );
}

// El wrapper NO se recorta: IntersectionObserver ignora por completo un
// elemento cuyo clip-path está cerrado, así que observaríamos algo invisible
// para siempre. Observamos el wrapper y dejamos que la regla `.is-in .curtain`
// abra el panel recortado.
export function Curtain({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useInView<HTMLDivElement>();
  return (
    <div ref={ref} className={className}>
      <div className="curtain h-full w-full">{children}</div>
    </div>
  );
}

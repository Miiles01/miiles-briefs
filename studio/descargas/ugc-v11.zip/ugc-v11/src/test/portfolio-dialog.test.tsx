import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { useState } from "react";
import { describe, expect, it } from "vitest";
import { PortfolioDialog } from "@/components/PortfolioDialog";

function Viewer() {
  const [open, setOpen] = useState(false);
  return <><button onClick={() => setOpen(true)}>Open</button><PortfolioDialog open={open} onOpenChange={setOpen} title="Media"><a href="#target">Target</a></PortfolioDialog></>;
}

describe("Portfolio viewer", () => {
  it("moves focus into the viewer and closes on Escape", async () => {
    render(<Viewer />);
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    const dialog = await screen.findByRole("dialog");
    expect(dialog.contains(document.activeElement)).toBe(true);
    fireEvent.keyDown(document.activeElement ?? document.body, { key: "Escape" });
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
  });
});